<?php

echo "Foo Bar\n";

