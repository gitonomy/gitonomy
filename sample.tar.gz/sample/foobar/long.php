<?php

/**
 * This file is a long PHP file.
 *
 * It's used for tests, because we want to be sure that codeviewer displays the
 * whole file with a proper height.
 */

$foo = "bar";

$x = '';
for ($i = 1; $i < 1000; $i++) {
    $x .= $foo;
}

$count = function ($string) {
    return count(explode('b', $string));
};

$j = $count($x);

$foo = "bar";

$x = '';
for ($i = 1; $i < 1000; $i++) {
    $x .= $foo;
}

$count = function ($string) {
    return count(explode('b', $string));
};

$j = $count($x);


$foo = "bar";

$x = '';
for ($i = 1; $i < 1000; $i++) {
    $x .= $foo;
}

$count = function ($string) {
    return count(explode('b', $string));
};

$j = $count($x);


$foo = "bar";

$x = '';
for ($i = 1; $i < 1000; $i++) {
    $x .= $foo;
}

$count = function ($string) {
    return count(explode('b', $string));
};

$j = $count($x);


$foo = "bar";

$x = '';
for ($i = 1; $i < 1000; $i++) {
    $x .= $foo;
}

$count = function ($string) {
    return count(explode('b', $string));
};

$j = $count($x);



