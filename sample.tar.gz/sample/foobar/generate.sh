#bin/sh

for (( i=1; i<=100; i++ )); do
	echo -n "$i" > "element_$i";
	git add "element_$i";
	git commit -am "Add element_$i";
done;
