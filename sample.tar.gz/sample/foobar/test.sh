#!/bin/bash
echo "You should see foo bar... or something like this\n";
php run.php
