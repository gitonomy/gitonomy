<?php

echo "Foo Bar\n";
echo "Today is: ".date("Y-m-d")."\n";
echo "The hour is: ".date('H:i')."\n";


