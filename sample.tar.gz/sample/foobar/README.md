Foo Bar project
===============

To execute:

$ php run.php

